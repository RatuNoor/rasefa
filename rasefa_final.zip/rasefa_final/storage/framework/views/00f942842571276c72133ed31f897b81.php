

<?php $__env->startSection('content'); ?>
    <div class="my-4">
        <h2 class="d-flex align-items-center">
            <i class="fas fa-boxes mr-2"></i> Halaman Produk
        </h2>
        <hr>

        <!-- Tombol Tambah Produk di atas kanan -->
        <div class="mb-3 d-flex justify-content-end">
            <a href="<?php echo e(route('produk.create')); ?>" class="btn btn-light">
                <i class="fas fa-plus"></i> Tambah Produk
            </a>
        </div>

        <table class="table table-bordered table-striped mt-4">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Nama Produk</th>
                    <th>Kategori</th>
                    <th>Harga</th>
                    <th>Stok</th>
                    <th style="width: 80px;" class="text-center">Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $produk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($product->id_produk); ?></td>
                        <td><?php echo e($product->nama_produk); ?></td>
                        <td><?php echo e($product->kategori_produk); ?></td>
                        <td><?php echo e($product->harga_produk); ?></td>
                        <td><?php echo e($product->stok); ?></td>
                        <td class="text-center">
                            <div class="btn-group">
                                <a href="<?php echo e(route('produk.edit', $product->id_produk)); ?>" class="btn btn-sm btn-warning"
                                    title="Edit">
                                    <i class="fas fa-pencil-alt"></i>
                                </a>
                                &nbsp;
                                <form action="<?php echo e(route('produk.destroy', $product->id_produk)); ?>" method="post"
                                    class="d-inline">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-sm btn-danger" title="Hapus"
                                        onclick="return confirm('Apakah Anda yakin ingin menghapus produk ini?');">
                                        <i class="fas fa-trash-alt"></i>
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="6" class="text-center">Tidak ada data produk.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ratun\OneDrive - Universitas Airlangga\semester 5\praktikum\basdat\rasefa_final\rasefa_final\resources\views/produk/index.blade.php ENDPATH**/ ?>