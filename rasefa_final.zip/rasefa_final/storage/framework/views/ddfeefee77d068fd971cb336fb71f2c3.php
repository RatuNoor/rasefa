<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
   <!-- Google Fots -->
   <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@100;200;300;400;500;600;700;800;900&display=swap"
        rel="stylesheet">
    <!-- Remixicon Icon -->
    <link href="https://cdn.jsdelivr.net/npm/remixicon@2.5.0/fonts/remixicon.css" rel="stylesheet">
    <!-- Remixicon Icon -->
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <!-- Main CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('style/main.css')); ?>">
    <title>eda</title>
    <link href="https://unpkg.com/tailwindcss@^2/dist/tailwind.min.css" rel="stylesheet">
</head>
<body>
 <!-- header -->
 <header class="ds-header" id="site-header">
        <div class="container">
            <div class="ds-header-inner">
                <!-- logo -->
                <a href="index.html" class="ds-logo">
                    <span>R</span>asefa
                </a>
                <!-- logo -->
                <!-- Navigation bar -->
                <ul class="ds-navbar">
                    <li>
                    <form action="<?php echo e(route('logout')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="ri-logout-box-r-line"6>Logout</button>
                    </form>
                    </li>
                    <li><a href="<?php echo e(asset('keranjang')); ?>" target="_blank"><i class="ri-shopping-cart-2-line"></i></a>
                    </li>
                    <li><a href="<?php echo e(asset ('akun-myorders')); ?>"><i class="ri-account-circle-line"></i></a></li>
                </ul>
                <!-- Navigation bar -->
                
            </div>
            <br>
            <h2 class="ds-headingeda">eda Pembelian Charts</h2>
        </div>
    </header>

    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <nav id="sidebar" class="col-md-3 col-lg-2 d-md-block bg-light sidebar">
                <div class="position-sticky">
                    <ul class="nav flex-column">
                        <li class="nav-item">
                            <a class="nav-link active" href="<?php echo e(route('chart.show', ['chart' => 'chart1'])); ?>">
                                Chart 1
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('chart.show', ['chart' => 'chart2'])); ?>">
                                Chart 2
                            </a>
                        </li>
                    </ul>
                </div>
            </nav>    

<div class="ds-katalog">
    <div class="container">
    <div class="container px-4 mx-auto">
    <div class="p-6 m-20 bg-white rounded shadow">
        <?php echo $chart->container(); ?>

    </div>
   </div>
    </div>
</div>


<script src="<?php echo e($chart->cdn()); ?>"></script>
<?php echo e($chart->script()); ?>

</body>
</html><?php /**PATH C:\Users\ratun\OneDrive - Universitas Airlangga\semester 5\praktikum\basdat\rasefa_final\rasefa_final3\rasefa_final\resources\views/eda.blade.php ENDPATH**/ ?>