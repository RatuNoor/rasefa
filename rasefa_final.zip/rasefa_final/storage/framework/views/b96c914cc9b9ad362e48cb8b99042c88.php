<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/remixicon@2.5.0/fonts/remixicon.css">
    <link rel="stylesheet" href="<?php echo e(asset('style/main.css')); ?>">
    <title>Keranjang</title>
</head>
<body>
    <header class="ds-header" id="site-header">
        <div class="container">
            <div class="ds-header-inner">
              <!-- logo -->
              <a href="index.html" class="ds-logo">
                <span>R</span>asefa
              </a>
              <ul class="ds-navbar ds-navbar-home">
                <li><a href="<?php echo e(asset('home')); ?>" target="_blank"><i class="ri-home-3-line"></i></a></li>
              </ul>
              <!-- logo -->
            </div>
        </div>
    </header>
<div class="container">                
<div class="contentbar">                
<h1>Keranjang</h1>
<table>
    <thead>
        <tr>
            <th>ID</th>
            <th>Nama Produk</th>
            <th>Kuantitas</th>
            <!-- Add more table headers for other columns as needed -->
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $keranjangItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($item->id); ?></td>
                <td><?php echo e($item->nama_produk); ?></td>
                <td><?php echo e($item->kuantitas); ?></td>
                <!-- Add more table data for other columns as needed -->
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
</body>
</html><?php /**PATH C:\appp\rasefa_final\resources\views/keranjang.blade.php ENDPATH**/ ?>