

<?php $__env->startSection('content'); ?>
    <div class="my-4">
    <h2 class="d-flex align-items-center">
            <i class="fas fa-boxes mr-2"></i> Sudah Sampai
        </h2>
        <table class="table table-bordered table-striped mt-4">
            <thead>
                <tr>
                    <th>List Barang</th>
                    <th>Nomor Resi</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $barangSudahSampai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $barang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($barang->nama_produk); ?></td>
                <td><?php echo e($barang->nomor_resi); ?></td>
                <td>
                    <?php if($barang->status == 'Sudah Sampai'): ?>
                    <form action="<?php echo e(route('konfirmasi-barang')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="nomor_resi" value="<?php echo e($barang->nomor_resi); ?>">
                        <input type="submit" value="Sudah Dikonfimasi">
                    </form>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\appp\rasefa_final\resources\views/sudah-sampai.blade.php ENDPATH**/ ?>