

<?php $__env->startSection('content'); ?>
    <div class="my-4">
        <h2 class="d-flex align-items-center">
            <i class="fas fa-boxes mr-2"></i> Toko
        </h2>
        <table class="table table-bordered table-striped mt-4">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Nama Toko</th>
                    <th>Alamat Toko</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $tokos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $toko): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($loop->index + 1); ?></td>
                <td><?php echo e($toko->nama_toko); ?></td>
                <td><?php echo e($toko->alamat_toko); ?></td>
                <td>
                    <a href="<?php echo e(route('toko.edit', ['id_toko' => $toko->id_toko])); ?>" class="btn btn-primary">Edit Toko</a>

                    <form action="<?php echo e(route('toko.destroy', $toko->id_toko)); ?>" method="POST" style="display: inline;">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger" onclick="return confirm('Anda yakin ingin menghapus toko ini?')">Hapus</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\appp\rasefa_final\resources\views/toko.blade.php ENDPATH**/ ?>