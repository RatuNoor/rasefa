

<?php $__env->startSection('content'); ?>
    <div class="my-4">
        <h2 class="d-flex align-items-center">
            <i class="fas fa-boxes mr-2"></i> Edit Produk
        </h2>
        <hr>

        <form action="<?php echo e(route('produk.update', $produk->id_produk)); ?>" method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <div class="form-group mb-3">
                <label for="id_toko">Nama Toko</label>
                <select name="id_toko" id="id_toko" class="form-control" required>
                    <?php $__currentLoopData = $tokos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $toko): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($toko->id_toko); ?>" <?php echo e($toko->id_toko == $produk->id_toko ? 'selected' : ''); ?>><?php echo e($toko->nama_toko); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div class="form-group mb-3">
                <label for="nama_produk">Nama Produk</label>
                <input type="text" name="nama_produk" id="nama_produk" class="form-control" value="<?php echo e($produk->nama_produk); ?>"
                    required>
            </div>

            <div class="form-group mb-3">
                <label for="kategori_produk">Kategori</label>
                <input type="text" name="kategori_produk" id="kategori_produk" class="form-control" value="<?php echo e($produk->kategori_produk); ?>"
                    required>
            </div>

            <div class="form-group mb-3">
                <label for="harga_produk">Harga Produk</label>
                <input type="number" name="harga_produk" id="harga_produk" class="form-control" value="<?php echo e($produk->harga_produk); ?>"
                    required>
            </div>

            <div class="form-group mb-3">
                <label for="stok">Stok</label>
                <input type="number" name="stok" id="stok" class="form-control" min="1" value="<?php echo e($produk->stok); ?>"
                    required>
            </div>

            <div class="form-group mb-3">
                <label for="gambar_produk">Media (Gambar atau Video MP4)</label>
                <input type="file" name="gambar_produk" id="gambar_produk" class="form-control" accept=".png, .jpg, .jpeg, .mp4">
            </div>

            <button type="submit" class="btn btn-primary">Update Produk</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ratun\OneDrive - Universitas Airlangga\semester 5\praktikum\basdat\rasefa_final\rasefa_final\resources\views/produk/edit.blade.php ENDPATH**/ ?>