

<?php $__env->startSection('content'); ?>
    <div class="my-4">
        <h2 class="d-flex align-items-center">
            <i class="fas fa-boxes mr-2"></i> Tambah Produk
        </h2>
        <hr>

        <form action="<?php echo e(route('produk.store')); ?>" method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group mb-3">
                <label for="id_toko">Nama Toko</label>
                <select name="id_toko" id="id_toko" class="form-control" required>
                    <option value="">-- Pilih Toko --</option>
                    <?php $__currentLoopData = $tokos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $toko): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($toko->id_toko); ?>"><?php echo e($toko->nama_toko); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div class="form-group mb-3">
                <label for="nama_produk">Nama Produk</label>
                <input type="text" name="nama_produk" id="nama_produk" class="form-control" required>
            </div>

            <div class="form-group mb-3">
                <label for="kategori_produk">Kategori</label>
                <input type="text" name="kategori_produk" id="kategori_produk" class="form-control" required>
            </div>

            <div class="form-group mb-3">
                <label for="harga_produk">Harga Produk</label>
                <input type="number" name="harga_produk" id="harga_produk" class="form-control" required>
            </div>

            <div class="form-group mb-3">
                <label for="stok">Stok</label>
                <input type="number" name="stok" id="stok" class="form-control" min="1" required>
            </div>

            <div class="form-group mb-3">
                <label for="gambar_produk">Media (Gambar atau Video MP4)</label>
                <input type="file" name="gambar_produk" id="gambar_produk" class="form-control" accept=".png, .jpg, .jpeg, .mp4"
                    required>
            </div>

            <button type="submit" class="btn btn-primary">Tambahkan Produk</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\appp\rasefa_final\resources\views/produk/create.blade.php ENDPATH**/ ?>