<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registrasi</title>
    <style>
        /* CSS styling (sesuaikan sesuai kebutuhan) */
        .rasefa {
            font-family: Lucida Handwriting, cursive;
            color: #DB7093;
        }
        body {
            font-family: Georgia, Serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .login-container {
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.2);
        }

        .login-container h2 {
            text-align: center;
        }

        .login-form {
            display: flex;
            flex-direction: column;
        }

        .form-group {
            margin: 10px 0;
        }

        .form-group label {
            font-weight: bold;
        }

        /* Meratakan posisi input */
        .form-group input {
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 3px;
            width: 80%; /* Mengisi lebar container */
        }

        .form-group button {
            background-color: #DB7093;
            color: #FFFFFF;
            border: none;
            padding: 10px;
            border-radius: 3px;
            cursor: pointer;
        }

        .register-link {
            text-align: center;
            margin-top: 10px;
        }

        .register-link a {
            text-decoration: none;
            color: #DB7093;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <h2 class="rasefa">Registrasi</h2>
        <form class="login-form" action="<?php echo e(route('registrasi.store')); ?>" method="POST">
            <?php echo csrf_field(); ?> <!-- Tambahkan token CSRF Laravel -->
            <div class="form-group">
                <label for="nama">Nama:</label>
                <input type="text" id="nama" name="nama" required>
            </div>
            <div class="form-group">
                <label for="alamat">Alamat:</label>
                <input type="text" id="alamat" name="alamat" required>
            </div>
            <div class="form-group">
                <label for="no_telp">Nomor Telepon:</label>
                <input type="text" id="no_telp" name="no_telp" required>
            </div>
            <div class="form-group">
                <label for="email">Email:</label>
                <input type="text" id="email" name="email" required>
            </div>
            <div class="form-group">
                <label for="password">Password:</label>
                <input type="password" id="password" name="password" required>
            </div>
            <div class="form-group">
                <button type="submit">Register</button>
            </div>
        </form>
        <div class="register-link">
            <a href="<?php echo e(route('login')); ?>">Already have an account? Login here</a>
        </div>
    </div>
</body>
</html>
<?php /**PATH C:\appp\rasefa_final\resources\views/registrasi.blade.php ENDPATH**/ ?>