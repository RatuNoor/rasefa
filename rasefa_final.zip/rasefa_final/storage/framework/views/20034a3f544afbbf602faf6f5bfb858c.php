

<?php $__env->startSection('content'); ?>
    <div class="text-center my-4">
            <i class="fas fa-boxes mr-2"><h2 style="font-family:serif;">Jumlah Toko dan Produk</h2>
            
            </i>
        <hr>
    </div>
    <div class="row">
        <!-- Card Toko -->
        <div class="col-md-6 mb-4">
            <div class="card">
                <div class="card-body text-center">
                    <i class="fas fa-store fa-3x mb-3"></i>
                    <h4 class="card-title">Toko</h4>
                    <p class="card-text"><?php echo e($jumlahToko); ?> Toko Tersedia</p>
                </div>
            </div>
        </div>

        <!-- Card Produk -->
        <div class="col-md-6 mb-4">
            <div class="card">
                <div class="card-body text-center">
                    <i class="fas fa-boxes fa-3x mb-3"></i>
                    <h4 class="card-title">Produk</h4>
                    <p class="card-text"><?php echo e($jumlahProduk); ?> Produk Tersedia</p>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\appp\rasefa_final\resources\views/seller.blade.php ENDPATH**/ ?>