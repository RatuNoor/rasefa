

<?php $__env->startSection('content'); ?>
    <div class="my-4">
        <h2 class="d-flex align-items-center">
            <i class="fas fa-store mr-2"></i> Halaman Toko
        </h2>
        <hr>

        <!-- Tombol Tambah Toko di atas kanan -->
        <div class="mb-3 d-flex justify-content-end">
            <a href="<?php echo e(route('toko.create')); ?>" class="btn btn-light">
                <i class="fas fa-plus"></i> Tambah Toko
            </a>
        </div>

        <table class="table table-bordered table-striped mt-4">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Nama Toko</th>
                    <th>Alamat Toko</th>
                    <th style="width: 80px;" clas="text-center">Aksi</th> <!-- Menyesuaikan lebar kolom -->
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $tokos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $toko): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($toko->id_toko); ?></td>
                        <td><?php echo e($toko->nama_toko); ?></td>
                        <td><?php echo e($toko->alamat_toko); ?></td>
                        <td class="text-center">
                            <div class="btn-group">

                                <a href="<?php echo e(route('toko.edit', $toko->id_toko)); ?>" class="btn btn-sm btn-warning" title="Edit">
                                    <i class="fas fa-pencil-alt"></i>
                                </a>
                                &nbsp;
                                <form action="<?php echo e(route('toko.destroy', $toko->id_toko)); ?>" method="post" class="d-inline">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-sm btn-danger" title="Hapus"
                                        onclick="return confirm('Apakah Anda yakin ingin menghapus toko ini?');">
                                        <i class="fas fa-trash-alt"></i>
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="4" class="text-center">Tidak ada data toko.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ratun\OneDrive - Universitas Airlangga\semester 5\praktikum\basdat\rasefa_final\rasefa_final\resources\views/toko/index.blade.php ENDPATH**/ ?>